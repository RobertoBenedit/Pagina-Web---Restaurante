# web_restaurant_italiano
En este tutorial vamos aprender a crear una página web de un restaurante totalmente responsive utilizando html5, css3 y JavaScript , para maquetar el sitio web utilizaremos  flexbox, ya que este tutorial va enfocado a que aprendas lo básico de esta tecnología de una manera practica, espero aprendas mucho y que si te gusto el video lo compartas con tus amigos.
https://youtu.be/QUCJ_CpkFbo
![MiniaturaRestaurante](https://user-images.githubusercontent.com/79062163/138543114-96ddb435-8ef3-4de1-8326-f79ff9a6c06a.jpg)
